package com.example.stu_paper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
